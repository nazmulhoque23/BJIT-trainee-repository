package com.bjit.authenticationdemo.demoauthentication.entity;

public enum Role {
    USER,
    ADMIN;
}
