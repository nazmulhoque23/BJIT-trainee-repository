package com.bjit.authenticationdemo.demoauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
