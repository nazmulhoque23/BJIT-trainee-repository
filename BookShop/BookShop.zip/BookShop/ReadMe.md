## create app image
```docker image build -t book_app . ```

## run composer
```dock-compose up -d```