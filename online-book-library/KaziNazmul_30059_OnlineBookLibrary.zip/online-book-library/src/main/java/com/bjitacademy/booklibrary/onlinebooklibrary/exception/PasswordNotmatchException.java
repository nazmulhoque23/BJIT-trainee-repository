package com.bjitacademy.booklibrary.onlinebooklibrary.exception;

public class PasswordNotmatchException extends RuntimeException{
    public PasswordNotmatchException(String message){
        super(message);
    }
}
