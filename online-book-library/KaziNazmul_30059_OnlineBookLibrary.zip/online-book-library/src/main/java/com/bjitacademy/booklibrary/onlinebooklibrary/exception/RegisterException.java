package com.bjitacademy.booklibrary.onlinebooklibrary.exception;

public class RegisterException extends RuntimeException{
    public RegisterException(String message){
        super(message);
    }
}
