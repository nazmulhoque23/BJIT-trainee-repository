package com.bjitacademy.booklibrary.onlinebooklibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
